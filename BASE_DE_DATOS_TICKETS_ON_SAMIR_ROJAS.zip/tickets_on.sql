-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 26-05-2022 a las 05:15:10
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tickets_on`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ciudades`
--

CREATE TABLE `ciudades` (
  `id_ciudad` int(11) NOT NULL,
  `ciudad` varchar(20) DEFAULT NULL,
  `precio` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `ciudades`
--

INSERT INTO `ciudades` (`id_ciudad`, `ciudad`, `precio`) VALUES
(1, 'BARRANQUILLA', 100),
(2, 'CARTAGENA', 200),
(3, 'SANTA MARTA', 300),
(4, 'FUNDACION', 400),
(5, 'BOGOTA', 500),
(6, 'MEDELLIN', 600),
(7, 'CAUCA', 700),
(8, 'CALI', 800),
(9, 'PEREIRA', 900),
(10, 'SINCELEJO', 1000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id_clientes` int(11) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `apellido` varchar(20) NOT NULL,
  `tipo_documento` int(11) NOT NULL,
  `numero_documento` int(11) DEFAULT NULL,
  `email` varchar(25) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `direccion` varchar(20) NOT NULL,
  `fecha` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id_clientes`, `nombre`, `apellido`, `tipo_documento`, `numero_documento`, `email`, `telefono`, `direccion`, `fecha`) VALUES
(76, 'RICARDO', 'GARCIA', 3, 123456, 'RICHAR@GMAIL.COM', '1244142', 'CALLE 110 # 87-48', '2022-05-25 00:17:22'),
(77, 'Samir', 'Rojas', 4, 1002130138, 'Samirrojas42@gmail.com', '3004354014', 'Cra 2 sur #89-35', '2022-05-25 00:20:33'),
(78, 'JANNEIRYS', 'JIMENEZ', 5, 123456789, 'JANNE@GMAIL.COM', '3220349958', 'Calle 54 # 45-23', '2022-05-25 00:21:07'),
(79, 'Andres', 'Perea', 4, 2147483647, 'Andres@gmail.com', '14565562323', 'CALLE 110 # 45-98', '2022-05-25 00:21:59'),
(80, 'SAMUEL', 'GUTIERREZ', 4, 8557443, 'SAMUELROJAS@GMAIL.COM', '538734425352', 'CRA 43 # 70-87', '2022-05-25 00:22:37'),
(82, 'ALEXIS', 'SANCHEZ', 3, 987654, 'ALEXIS20221@HOTMAIL.COM', '133124', 'CALLE 44 #45-65', '2022-05-25 00:27:11'),
(86, 'JHONATAN', 'MARCHESE', 4, 123, 'MACHESE@GMAIL.COM', '124141', 'CALLE 87 # 45-56', '2022-05-25 00:32:51'),
(87, 'JAMIR', 'MUNIVE', 5, 783567291, 'JMUNIVE@GMAIL.COM', '98337497687', 'CALLE 45 # 45-21', '2022-05-25 00:33:29'),
(88, 'ALDAIR', 'JIMENEZ', 4, 123450321, 'JALDAIRJIMENZ@GMAIL.COM', '893678762', 'CRA 50 # 45-32', '2022-05-25 00:34:06'),
(90, 'HANNER', 'VERBEL', 4, 1234, 'HANEVBG@GMAIL.COM', '123131312', 'CRA 45 # 54-32', '2022-05-25 00:35:24');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `horarios`
--

CREATE TABLE `horarios` (
  `id_horario` int(11) NOT NULL,
  `tipo_horario` int(11) NOT NULL,
  `descripcion_horario` varchar(20) DEFAULT NULL,
  `Hora` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `horarios`
--

INSERT INTO `horarios` (`id_horario`, `tipo_horario`, `descripcion_horario`, `Hora`) VALUES
(1, 1, 'Mañana', '08:00:00'),
(2, 2, 'Mañana', '10:00:00'),
(3, 3, 'Mañana', '12:00:00'),
(4, 4, 'Tarde', '14:00:00'),
(5, 5, 'Tarde', '16:00:00'),
(6, 6, 'Noche', '18:00:00'),
(7, 7, 'Noche', '20:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tickets`
--

CREATE TABLE `tickets` (
  `id_tickets` int(11) NOT NULL,
  `id_Ciudad` int(11) NOT NULL,
  `id_horario` int(11) NOT NULL,
  `numero_documento_cliente` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tickets`
--

INSERT INTO `tickets` (`id_tickets`, `id_Ciudad`, `id_horario`, `numero_documento_cliente`) VALUES
(0, 3, 2, 123),
(1, 1, 1, 1002130138),
(2, 3, 4, 123456),
(3, 4, 3, 1234),
(4, 2, 7, 987654),
(5, 8, 4, 8557443),
(6, 5, 3, 123450321),
(7, 6, 2, 123456789),
(8, 9, 5, 783567291),
(9, 10, 3, 2147483647),
(10, 8, 6, 1002130138),
(11, 5, 3, 2147483647),
(12, 3, 6, 123),
(13, 7, 3, 783567291),
(14, 2, 7, 123456789),
(15, 10, 4, 8557443),
(16, 5, 3, 2147483647);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_documento`
--

CREATE TABLE `tipo_documento` (
  `id_tipo_documento` int(11) NOT NULL,
  `documento` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tipo_documento`
--

INSERT INTO `tipo_documento` (`id_tipo_documento`, `documento`) VALUES
(3, 'Cedula Extranjera'),
(4, 'Cedula Ciudadania'),
(5, 'Pasaporte');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `usuario`, `password`) VALUES
(1, 'Sam117', 'samir123');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `ciudades`
--
ALTER TABLE `ciudades`
  ADD PRIMARY KEY (`id_ciudad`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id_clientes`),
  ADD UNIQUE KEY `numero_documento_UNIQUE` (`numero_documento`),
  ADD KEY `clientes_ibfk_2` (`tipo_documento`);

--
-- Indices de la tabla `horarios`
--
ALTER TABLE `horarios`
  ADD PRIMARY KEY (`id_horario`);

--
-- Indices de la tabla `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id_tickets`),
  ADD KEY `tickets_ibfk_1` (`id_horario`),
  ADD KEY `tickets_ibfk_2` (`id_Ciudad`),
  ADD KEY `numero_documento_idx` (`numero_documento_cliente`);

--
-- Indices de la tabla `tipo_documento`
--
ALTER TABLE `tipo_documento`
  ADD PRIMARY KEY (`id_tipo_documento`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `usuario` (`usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `ciudades`
--
ALTER TABLE `ciudades`
  MODIFY `id_ciudad` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id_clientes` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD CONSTRAINT `clientes_ibfk_2` FOREIGN KEY (`tipo_documento`) REFERENCES `tipo_documento` (`id_tipo_documento`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `tickets`
--
ALTER TABLE `tickets`
  ADD CONSTRAINT `numero_documento` FOREIGN KEY (`numero_documento_cliente`) REFERENCES `clientes` (`numero_documento`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `tickets_ibfk_1` FOREIGN KEY (`id_horario`) REFERENCES `horarios` (`id_horario`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tickets_ibfk_2` FOREIGN KEY (`id_Ciudad`) REFERENCES `ciudades` (`id_ciudad`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
